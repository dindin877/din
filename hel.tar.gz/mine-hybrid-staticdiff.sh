./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RGageHpeiJXWrvadgqao65izi5Fo6mn4mk.jj -p d=16384s,hybrid --cpu 2
