./hellminer -c stratum+tcp://ap.luckpool.net:3956#xnsub -u RGageHpeiJXWrvadgqao65izi5Fo6mn4mk.k -p x --cpu 2
